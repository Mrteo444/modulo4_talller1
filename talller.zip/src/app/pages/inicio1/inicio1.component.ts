import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-inicio1',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './inicio1.component.html',
  styleUrl: './inicio1.component.css'
})
export class Inicio1Component {

}
